var bandApp = angular.module('bandApp', ['ui.router','ngSanitize']);

bandApp.config(['$stateProvider','$urlRouterProvider',function($stateProvider,$urlRouterProvider){
	$stateProvider.state('bands',{
		url: '/bands',
		templateUrl: 'pages/bands.ejs',
		controller: 'mainCtrl'
	});
	$stateProvider.state('details', {
  		url: '/details/{bandId}',
  		templateUrl: 'pages/details.ejs',
  		controller: 'detailsCtrl'
	});
	$urlRouterProvider.otherwise('/bands');
}]);

bandApp.controller('mainCtrl',['$scope','$http',function($scope,$http){
	$http.get('/bands').then(function(bands){
		$scope.bands = bands.data;
	});
}]);

bandApp.controller('detailsCtrl', ['$scope','$http','$stateParams', function($scope,$http,$stateParams) {
  var ID = $stateParams.bandId;
  $http.get('/details/'+ID).then(function(bands) {
  	console.log(bands.data.Name);//this gives me the object array...
  	$scope.bandName = bands.data.Name;
  	$scope.bandBio = bands.data.Bio;
    //$scope.Name = bands.data[$stateParams.bandId].Name;
    //console.log(ID); Properly spits out the RIGHT ID!!
  });
}]);